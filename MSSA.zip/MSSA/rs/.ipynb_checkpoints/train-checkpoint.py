import os
os.environ['PYTORCH_CUDA_ALLOC_CONF'] = 'max_split_size_mb:128'
from model1030 import ImageEncoder, Bert, MatchingModel  #导入模型
from torch.utils.data import Dataset, DataLoader
from torch.autograd import Variable
from tqdm import tqdm,trange
import random
import torch
import torch.nn as nn
import numpy as np
import numpy
import yaml
import data            #导入data
import argparse
import torch.nn.functional as F
from matplotlib import pyplot as plt
from ipdb import set_trace
import copy

from torch.utils.data.sampler import SubsetRandomSampler
# from tda import set_requires_grad
from transformers import BertTokenizer
import torch.optim as optim
from transformers import BertModel, BertConfig
from transformers import AutoConfig, AutoModel, AutoTokenizer
import sklearn.preprocessing
from sklearn.metrics.pairwise import cosine_similarity
import scipy.spatial
from eval import ratk,i2t5,t2i5        #计算图像和文本间的相似度   （评估指标）
import csv
import json
import time 
import matplotlib.pyplot as plt
from torch.cuda.amp import GradScaler, autocast   #混合精度
from torch.utils.tensorboard import SummaryWriter
from config import parser_options                   #导入配置文件
import torch.nn.functional as F
import warnings
warnings.filterwarnings('ignore')         #过滤警告
import torch.optim.lr_scheduler as lr_scheduler
from torchvision import transforms
import logging
import argparse

#配置日志记录
logging.basicConfig(filename='model_processing.log', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

#打印模型所有子模块和参数
def print_model_structure(model, indent=0):
    for name, module in model.named_children():
        print(' ' * indent + f'{name}: {module}')
        print_model_structure(module, indent + 2)

#绘制并保存训练指标图
def plot_and_save_metrics(data, title="Training Progress", ylabel="Value", filename="training_plot.png"):
    epochs = range(1, len(data) + 1)    #X轴表示epoch
    plt.figure(figsize=(10, 5))
    plt.plot(epochs, data, label=ylabel, color='blue', marker='o', linestyle='-')   #绘制折线图
    plt.title(title)
    plt.xlabel('Epoch')
    plt.ylabel(ylabel)
    plt.grid(True)
    plt.legend()         #图例
    plt.savefig(filename)    #保存为图像文件
    plt.close()  #


#用于设置模型中所有参数的 requires_grad 属性。该属性决定了在反向传播过程中是否计算梯度。
def set_requires_grad(model, requires_grad=True):
    for param in model.parameters():
        param.requires_grad = requires_grad

def setup_seed(seed):
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.backends.cudnn.deterministic = True

#三元组损失（三元组损失的目标是使得一个锚点样本（Anchor）与一个正样本（Positive）之间的距离
# 小于与一个负样本（Negative）之间的距离，至少一个边距（Margin）。
def triplet_loss(emb_v, 
               emb_text_pos, 
               emb_text_neg, 
               emb_text, 
               emb_v_pos, 
               emb_v_neg,
               device,
              ):
    margin = 0.5       #损失的边距
    # margin = 1
    alpha = 1
    #视觉嵌入与正/负样本文本嵌入之间的余弦相似度损失
    v_loss_pos = 2-torch.cosine_similarity(emb_v, emb_text_pos,dim=1) #视觉嵌入和正样本文本嵌入之间的损失
    v_loss_neg = 2-torch.cosine_similarity(emb_v, emb_text_neg,dim=1) #视觉嵌入和负样本文本嵌入之间的损失

    #文本嵌入与正/负样本视觉嵌入之间的余弦相似度损失
    t_loss_pos = 2-torch.cosine_similarity(emb_text, emb_v_pos,dim=1) #文本嵌入和正样本视觉嵌入之间的损失
    t_loss_neg = 2-torch.cosine_similarity(emb_text, emb_v_neg,dim=1) #文本嵌入和负样本视觉嵌入之间的损失

    #计算三元组损失（双向）
    #triplet_loss = torch.sum(torch.max(torch.zeros(1).to(device), margin + alpha * v_loss_pos - v_loss_neg)) + torch.sum(torch.max(torch.zeros(1).to(device),margin+alpha*t_loss_pos-t_loss_neg))
    #计算 image-text 损失
    image_text_loss = torch.sum(torch.max(torch.zeros(1).to(device), margin + alpha * v_loss_pos - v_loss_neg))
    
    #计算 text-image 损失
    text_image_loss = torch.sum(torch.max(torch.zeros(1).to(device), margin + alpha * t_loss_pos - t_loss_neg))
    # text_image_loss = text_image_loss *5
    #计算总的三元组损失（双向）
    triplet_loss = image_text_loss +text_image_loss
    return triplet_loss, image_text_loss, text_image_loss
    #return  triplet_loss 


def main(args_re):
    torch.set_num_threads(1)          #pytorch线程数
    options = parser_options()        #调用函数解析配置选项
    #opt.path_opt = 'G:/Image-Text Matching/MSA-main/MSA-main/option/RSITMD.yaml'
    

    #加载数据
    train_dataloader, _, test_dataloader = data.get_loaders(options["dataset"]["batch_size"], options)

    device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
    #setup_seed(1)    #设置随机种子
   
    #初始化模型
    image_encoder = ImageEncoder(args_re).to(device)      #图像编码器
    text_encoder = Bert(args_re.bert_name).to(device)     #文本编码器
    model = MatchingModel(image_encoder,text_encoder,embed_dim=768, num_heads=8,drop_prob=0.1).to(device)


    #优化器
    optimizer = optim.AdamW(model.parameters(), lr=args_re.lr,
                             weight_decay=0.01, betas=(0.9, 0.999), eps=1.0e-8)
    
    # 初始化学习率调度器
    scheduler = lr_scheduler.StepLR(optimizer, step_size=10, gamma=0.1)

     # 设置累积步数
    accumulation_steps = 4

    mr = 0              
    ep = 1
    tr1 = 0
    tr5 = 0
    tr10 = 0
    vr1 = 0
    vr5 = 0
    vr10 = 0
    nums = 0
    loss1 = []   #存储三元组损失
    loss2 = []      #存储对比损失
    train_loss = []   #存储训练损失
    metric = []

    for epoch in range(1, args_re.epochs + 1):

        total_loss = 0
        total_image_text_loss = 0
        total_text_image_loss = 0
        loss_1 = 0      #三元组损失
        loss_2 = 0      #对比损失
        total_loss = 0
        nums = 0
        gradient_norms = []  # 存储每个step的梯度范数


        image_encoder.train()            #训练模式
        text_encoder.train()
        model.train()

        # a = 0
        #遍历训练数据加载器
        #for step, (rs_img, text,iids) in tqdm(enumerate(train_dataloader), leave=False):
        for step, (rs_img, text,iids) in tqdm(enumerate(train_dataloader),total=len(train_dataloader),
                                              desc=f"Epoch [{epoch}/{args_re.epochs}]",leave=True):
            # print(f"Step: {step}")
            # if step > 26:
                # break
            rs_img = rs_img.to(torch.float32).to(device)   #将图像转换为浮点张量
            token_input_ids = []    #
            token_attentions = []      #对文本样本进行标记化和编码，生成输入ID和注意力掩码
            cap_len = []            #文本的长度
            #对文本数据进行tokenizer，并生产相应的ID，注意力掩码，文本长度
            for i in range(len(text)):
                # set_trace()
                '''text-model对文本进行tokenize '''
                token_ids = text_encoder.tokenizers.encode_plus(text[i],
                                                padding="max_length",   #填充到最大长度
                                                max_length=31,          #最大长度为31
                                                add_special_tokens=True, #添加特殊标记（如 [CLS] 和 [SEP]）
                                                return_tensors='pt',    #返回pytorch张量
                                                return_attention_mask=True,  #返回注意力掩码
                                                truncation=True      #文本超过最大长度，就截断
                                                )
                token_input_ids.append(token_ids['input_ids'][0])     #存储输入id
                token_attentions.append(token_ids['attention_mask'][0])   #存储注意力掩码
                cap_len.append(int(token_ids['attention_mask'][0].sum().cpu().numpy()))   #存储文本长度
          
            #转换数据类型         
            cap_len = np.array(cap_len)
            token_ids = torch.stack(token_input_ids).to(device)
            token_attentions = torch.stack(token_attentions).to(device)

            # set_trace()
            optimizer.zero_grad()                  #梯度清零
            set_requires_grad(model)      #模型是否需要计算梯度
            # rs_image_feature,s_8,s_16,s_32  = image_encoder(rs_img)    #提取图像特征
            # text_feature,text_tokens_embeddings,sequence_outputs_all = text_encoder(token_ids, token_attentions)
            # print(text_feature.shape)
            # print(rs_image_feature.shape)
#------------------------------------------------------------------------
            #前向传播
            enhanced_image_features, enhanced_text_features = model(token_ids, token_attentions, rs_img,num_seed=token_attentions.shape[0])
            # #  # 打印中间变量
            # # #print(f"Step: {step}")
            # # # print(f"Image features shape: {enhanced_image_features.shape}")
            # # # print(f"Text features shape: {enhanced_text_features.shape}")

            #  # 确保特征维度一致
            # if enhanced_image_features.size(1) != enhanced_text_features.size(1):
            #     # 如果特征维度不一致，进行适当的处理
            #     if enhanced_image_features.size(1) > enhanced_text_features.size(1):
            #         enhanced_image_features = enhanced_image_features[:, :enhanced_text_features.size(1), :]
            #     else:
            #         enhanced_text_features = enhanced_text_features[:, :enhanced_image_features.size(1), :]

            # 转换为二维数组，以便矩阵相乘
            # sim = torch.einsum("nlc,nsc->nls", enhanced_image_features, enhanced_text_features)/enhanced_image_features.size(-1)**0.5
            # sim = sim.detach().cpu().numpy()
            # enhanced_image_features = enhanced_image_features.detach().cpu().numpy()
            # enhanced_text_features = enhanced_text_features.detach().cpu().numpy()
            # res = np.empty((enhanced_image_features.shape[0],2), dtype=int)
            # for i in range(enhanced_image_features.shape[0]):
            #     idx0,idx1 = np.where(sim[i] == np.max(sim[i]))
            #     res[i][0] = idx0[0]
            #     res[i][1] = idx1[0]
            # idxa = res[:,:1].reshape(-1)
            # # print(idxa)
            # idxb = res[:,1:].reshape(-1)
            # # print(idxb)
            # idxa_ =[i for i in range(enhanced_image_features.shape[0])]
            # enhanced_image_features = torch.Tensor( enhanced_image_features[idxa_,idxa,:]).cuda()
            # enhanced_text_features = torch.Tensor(enhanced_text_features[idxa_,idxb,:]).cuda()
            enhanced_image_features = enhanced_image_features.reshape(enhanced_image_features.size(0), -1)
            enhanced_text_features = enhanced_text_features.reshape(enhanced_text_features.size(0), -1)
    
            text_feature = enhanced_text_features
            rs_image_feature = enhanced_image_features
            # print(enhanced_image_features.shape)
            # print(enhanced_text_features.shape) 
            #归一化
            # text_feature = text_feature / text_feature.norm(dim=1, keepdim=True) 
            # rs_image_feature = rs_image_feature / rs_image_feature.norm(dim=1, keepdim=True)
             # 打印归一化后的特征
            # print(f"Normalized text features shape: {text_feature.shape}")
            # print(f"Normalized image features shape: {rs_image_feature.shape}")
            # print(rs_image_feature.shape)
            # print(rs_image_feature)
            # print(text_feature.shape)
            # print(text_feature)
#------------------------------------------------------------------------   
            # triplet loss          三元组损失
            #创建邻接矩阵和掩码矩阵
            adj_mat = np.eye(rs_img.shape[0])
            mask_mat_ = np.ones_like(adj_mat) - adj_mat            

            mask_mat = 1000000*adj_mat+mask_mat_    
        
            #图像-文本的相似度矩阵
            sim_it=scipy.spatial.distance.cdist(rs_image_feature.detach().cpu().numpy(), text_feature.detach().cpu().numpy(), 'cosine')
            img_sim_mat = mask_mat*sim_it
            # print(img_sim_mat.shape)
            img_neg_text_idx = np.argmin(img_sim_mat, axis=1).astype(int)  #img_sim_mat正样本的位置都是一个很大的数
            img_pos_text_idx = np.argmax(img_sim_mat, axis=1).astype(int)  #img_sim_mat正样本的位置都是一个很大的数
            # img_pos_text_idx=np.argsort(img_sim_mat,axis=1)[::-1]
            # print(img_pos_text_idx.shape)
            # img_pos_text_idx=img_pos_text_idx[:5]
            # img_neg_text_idx=np.argsort(img_sim_mat,axis=1)[::-1]
            # img_neg_text_idx=img_neg_text_idx[5:24]
            # print(img_pos_text_idx.shape)
            # print(img_neg_text_idx)
            img_neg_text = text_feature[img_neg_text_idx, :]   #将困难的文本负样本特征挑选出来
            img_pos_text = text_feature  #将困难的文本负样本特征挑选出来
            emb_t_neg = img_neg_text
            
            # #文本-图像的相似度矩阵
            sim_ti = scipy.spatial.distance.cdist(text_feature.detach().cpu().numpy(), rs_image_feature.detach().cpu().numpy(), 'cosine')
            text_sim_mat = mask_mat*sim_ti
            text_neg_img_idx = np.argmin(text_sim_mat, axis=1).astype(int)
            text_pos_img_idx = np.argmax(text_sim_mat, axis=1).astype(int)
            # text_pos_img_idx=np.argsort(text_sim_mat,axis=-1)[::-1][:5]
            # text_neg_img_idx=np.argsort(text_sim_mat,axis=-1)[::-1][5:24]
            text_neg_img = rs_image_feature[text_neg_img_idx, :]   #将困难的图像负样本特征挑选出来
            text_pos_img = rs_image_feature  
            emb_v_neg = text_neg_img
            # print(emb_v_neg.shape)
            # print(emb_t_neg.shape)
            #定义正样本特征
            emb_v_pos = text_pos_img
            emb_t_pos = img_pos_text
            # print(emb_v_pos.shape)
            # print(emb_t_pos.shape)
            #  # 打印相似度矩阵和负样本索引
              #图像-文本的相似度矩阵
            # sim_it=scipy.spatial.distance.cdist(rs_image_feature.detach().cpu().numpy(), text_feature.detach().cpu().numpy(), 'cosine')
            # img_sim_mat = mask_mat*sim_it
            # img_neg_text_idx = np.argmin(img_sim_mat, axis=1).astype(int)  #img_sim_mat正样本的位置都是一个很大的数
            # img_neg_text = text_feature[img_neg_text_idx, :]   #将困难的文本负样本特征挑选出来
            # emb_t_neg = img_neg_text
            
            # #文本-图像的相似度矩阵
            # sim_ti = scipy.spatial.distance.cdist(text_feature.detach().cpu().numpy(), rs_image_feature.detach().cpu().numpy(), 'cosine')
            # text_sim_mat = mask_mat*sim_ti
            # text_neg_img_idx = np.argmin(text_sim_mat, axis=1).astype(int)
            # text_neg_img = rs_image_feature[text_neg_img_idx, :]   #将困难的图像负样本特征挑选出来
            # emb_v_neg = text_neg_img

            # #定义正样本特征
            # emb_v_pos = rs_image_feature
            # emb_t_pos = text_feature

            # print(f"Image-text similarity matrix shape: {sim_it.shape}")
            # print(f"Text-image similarity matrix shape: {sim_ti.shape}")
            # print(f"Negative text indices: {img_neg_text_idx}")
            # print(f"Negative image indices: {text_neg_img_idx}")


            #计算三元组损失
            tripletloss, image_text_loss, text_image_loss= triplet_loss(rs_image_feature, 
            emb_t_pos, 
            emb_t_neg, 
            text_feature, 
            emb_v_pos, 
            emb_v_neg,
            device
            )

            loss = tripletloss
             
             # 反向传播和优化
            loss.backward()

             # 梯度裁剪
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)

            # 打印损失值和梯度范数（每100个step打印一次）
            # if step % 300 == 0:
            #     print(f"Step: {step}")
            #     print(f"Triplet loss: {tripletloss.item()}")

            #     total_norm = 0
            #     for p in model.parameters():
            #         if p.grad is not None:
            #             param_norm = p.grad.data.norm(2)
            #             total_norm += param_norm.item() ** 2
            #     total_norm = total_norm ** (1. / 2)
            #     gradient_norms.append(total_norm)  # 记录梯度范数
            #     print(f"Gradient norm: {total_norm}")

            optimizer.step()

            total_loss += loss.item()
            total_image_text_loss += image_text_loss.item()
            total_text_image_loss += text_image_loss.item()
            nums += 1
        
        # 计算平均损失
        mean_loss = total_loss / nums
        mean_image_text_loss = total_image_text_loss / nums
        mean_text_image_loss = total_text_image_loss / nums
        logging.info(f'Epoch [{epoch}/{args_re.epochs}], Mean Triplet Loss: {mean_loss:.4f}, Mean Image-Text Loss: {mean_image_text_loss:.4f}, Mean Text-Image Loss: {mean_text_image_loss:.4f}')
        print(f'Epoch [{epoch}/{args_re.epochs}], Loss: {total_loss/len(train_dataloader):.4f}')
        
       
        del rs_image_feature  #Delete variables to save  memory
        del text_feature
#-------------------------------------------------------------------------------
        #test   
        with torch.no_grad():
            image_encoder.eval()
            text_encoder.eval()
            model.eval()          #eval模式

            #创建空列表以存储图像和文本特征、文本ID和注意力掩码
            image_features = []

            text_features = []
            attention_test = []
            text_ids_test = []

            #遍历测试数据集加载器中的每个批次，提取图像和文本特征
            #for step, (rs_img, text,_) in tqdm(enumerate(test_dataloader), leave=False):
            for step, (rs_img, text,_) in tqdm(enumerate(test_dataloader),total=len(test_dataloader),
                                        desc=f"Epoch [{epoch}/{args_re.epochs}]",leave=True):
                # if step >= 525:
                    # break
                # set_trace()
                start_time = time.time()
                rs_img = rs_img.to(torch.float32).to(device)   #将图像转换为浮点张量

                
                # rs_image_feature,s_8,s_16,s_32  = image_encoder(rs_img)   #提取图像特征

                ############################################################
               
                #_,rs_image_feature2 = img_map(rs_image_feature)     #特征映射
                
                ###############################################################
                #处理文本数据
                token_ids = text_encoder.tokenizers.encode_plus(text[0],
                                                    padding="max_length",
                                                    max_length=31,
                                                    add_special_tokens=True,
                                                    return_tensors='pt',
                                                    return_attention_mask=True,
                                                    truncation=True
                                                    )
                #提取文本特征
                # text_feature,text_embedding_test,sequence_outputs_all = text_encoder(token_ids['input_ids'].to(device), token_ids['attention_mask'].to(device))
                #pdb.set_trace()
                enhanced_image_features, enhanced_text_features = model(token_ids['input_ids'].to(device), token_ids['attention_mask'].to(device), rs_img,rs_img)
                # print(text_feature.shape)
                # print(rs_image_feature.shape)
                #确保特征维度一致
                # if enhanced_image_features.size(1) != enhanced_text_features.size(1):
                #     # 如果特征维度不一致，进行适当的处理
                #     if enhanced_image_features.size(1) > enhanced_text_features.size(1):
                #         enhanced_image_features = enhanced_image_features[:, :enhanced_text_features.size(1), :]
                #     else:
                #         enhanced_text_features = enhanced_text_features[:, :enhanced_image_features.size(1), :]

                # # # 转换为二维数组，以便矩阵相乘
                # sim = torch.einsum("nlc,nsc->nls", enhanced_image_features, enhanced_text_features)/enhanced_image_features.size(-1)**0.5
                # sim = sim.detach().cpu().numpy()
                # enhanced_image_features = enhanced_image_features.detach().cpu().numpy()
                # enhanced_text_features = enhanced_text_features.detach().cpu().numpy()
                # res = np.empty((enhanced_image_features.shape[0],2), dtype=int)
                # for i in range(enhanced_image_features.shape[0]):
                #     idx0,idx1 = np.where(sim[i] == np.max(sim[i]))
                #     res[i][0] = idx0[0]
                #     res[i][1] = idx1[0]
                # idxa = res[:,:1].reshape(-1)
                # # print(idxa)
                # idxb = res[:,1:].reshape(-1)
                # # print(idxb)
                # idxa_ =[i for i in range(enhanced_image_features.shape[0])]
                # enhanced_image_features =torch.Tensor( enhanced_image_features[idxa_,idxa,:])
                # enhanced_text_features = torch.Tensor(enhanced_text_features[idxa_,idxb,:])
                enhanced_image_features = enhanced_image_features.reshape(enhanced_image_features.size(0), -1)
                enhanced_text_features = enhanced_text_features.reshape(enhanced_text_features.size(0), -1)
                # print(enhanced_image_features.shape)
                # print(enhanced_text_features.shape) 
                text_feature = enhanced_text_features
                rs_image_feature = enhanced_image_features


                #存储特征和掩码
                # text_ids_test.append(token_ids['input_ids'][0])
                # attention_test.append(token_ids['attention_mask'][0])
   
                image_features.append(rs_image_feature[0])
 
                text_features.append(text_feature[0])
                # end_time = time.time()              #计算前向传播时间
                # elapsed_time_ms = (end_time - start_time) * 1000

                # print(f"Forward pass time: {elapsed_time_ms:.3f} ms")
    
            #堆叠特征和掩码
            image_features = torch.stack(image_features).to(device)

            # print(image_features.shape)
            text_features = torch.stack(text_features).to(device)
         
            # text_ids_test = torch.stack(text_ids_test).to(device)
            # attention_test = torch.stack(attention_test).to(device)


            text_features = text_features
            image_features = image_features
            #pdb.set_trace()
            #归一化
            # text_features = text_features / text_features.norm(dim=1, keepdim=True)
            # image_features = image_features / image_features.norm(dim=1, keepdim=True)
            # print(image_features.shape)
            # print(image_features)
            # print(text_features.shape)
            # print(text_features)
######################################
            #转换为numpy数组
            image_features = image_features.cpu().numpy().copy()
            text_features = text_features.cpu().numpy().copy()
            # text_features=torch.tensor(text_features)
            image_features = np.array([image_features[i] for i in range(0, len(image_features), 5)])
            # image_features = torch.tensor(image_features)
            # idx = torch.randperm(image_features.size(0))
            # image_features = image_features[idx,:].view(image_features.size()).numpy()
            # idx = torch.randperm(text_features.size(0))
            # text_features = text_features[idx,:].view(text_features.size()).numpy()
            #pdb.set_trace()
            #计算检索准确率
            # print(image_features.shape)
            # print(text_features.shape)
            t_r1, t_r5, t_r10,_,_ = i2t5(image_features,text_features)   #image-text
            v_r1, v_r5, v_r10,_,_ = t2i5(image_features,text_features)   #text-image
#####################################

            mean_rat = (t_r1+t_r5+t_r10+v_r1+v_r5+v_r10)/6      #计算平均检索准确率
            #更新最佳模型
            if mr <= mean_rat:
                mr = mean_rat
                ep = epoch
                tr1 = t_r1
                tr5 = t_r5
                tr10 = t_r10
                vr1 = v_r1
                vr5 = v_r5
                vr10 = v_r10

                #save weight   保存模型权重

                # best_img_model= copy.deepcopy(img_model.state_dict())
                # best_text_model= copy.deepcopy(text_model.state_dict())
                # best_img_map= copy.deepcopy(img_map.state_dict())
                # torch.save(best_img_model,'./weight/best_img_model.pth')
                # torch.save(best_text_model,'./weight/best_text_model.pth')
                # torch.save(best_img_map,'./weight/best_img_map.pth')
            metric.append(mean_rat)
            print(f"this epoch: {epoch}, mean_rat: {mean_rat},best mean_rat: {mr}, best epoch: {ep}")
            # print(mr)
            # print(ep)      #打印和记录度量值

            #打印检索准确率和平均检索准确率   tqdm.write
            logging.info(f't_r1={t_r1}, t_r5={t_r5}, t_r10={t_r10}, '
                       f'v_r1={v_r1}, v_r5={v_r5}, v_r10={v_r10}, '
                       f'mr={(t_r1+t_r5+t_r10+v_r1+v_r5+v_r10)/6} ')
            del image_features  
            del text_features      #清理内存



if __name__ == '__main__':
    arg_parser = argparse.ArgumentParser(description='Train a resnet on opt_name')
    arg_parser.add_argument('--epochs', type=int, default=20)     # epoch 60
    arg_parser.add_argument("--lr", type=float, default=0.00001, help="adam: learning rate")  # 学习率0.00001
    arg_parser.add_argument('--bert_name', default='/hy-tmp/rs/BERT/bert-base-uncased', type=str)

    args_re = arg_parser.parse_args()

    main(args_re)